const chatBody = document.getElementById("chat-body");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
// Enable send button when there's input
userInput.addEventListener("input", () => {
  sendBtn.disabled = userInput.value.trim() === "";
});

// Handle send button click
sendBtn.addEventListener("click", () => {
  sendMessage();
});

// Handle Enter key press
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  addMessage(message, "user");
  userInput.value = "";
  sendBtn.disabled = true;

  setTimeout(() => {
    generateBotResponse(message);
  }, 500);
}

function addMessage(text, sender) {
  const chatBody = document.getElementById("chat-body");
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message", sender);
  msgDiv.textContent = text;
  chatBody.appendChild(msgDiv);
  chatBody.scrollTop = chatBody.scrollHeight;
}


function generateBotResponse(userMsg) {
  const lower = userMsg.toLowerCase();
  let reply = "";

  if (lower.includes("what is ai")) {
    reply = "AI stands for Artificial Intelligence. It's the simulation of human intelligence in machines.";
  } else if (lower.includes("machine learning")) {
  reply = "Machine learning is a subset of AI that allows systems to learn from data without being explicitly programmed.";
} else if (lower.includes("chatgpt")) {
  reply = "ChatGPT is a language model developed by OpenAI that can generate human-like text based on input.";
} else if (lower.includes("weather")) {
  reply = "I'm not connected to live weather data, but you can check a weather site or app like Weather.com 🌤️";
} else if (lower.includes("python")) {
  reply = "Python is a popular, beginner-friendly programming language used in web development, AI, data science, and more.";
} else if (lower.includes("time")) {
  reply = `The current time is ${new Date().toLocaleTimeString()}.`;
} else if (lower.includes("your name") || lower.includes("who are you")) {
  reply = "I'm a virtual assistant created to help answer your questions and simulate ChatGPT's behavior.";
} else if (lower.includes("hello") || lower.includes("hi")) {
  reply = "Hey there! 👋 How can I assist you today?";
} else if (lower.includes("news")) {
  reply = "I'm not connected to live news feeds, but you can visit Google News or any major news outlet for updates.";
} else if (lower.includes("ai")) {
  reply = "Artificial Intelligence (AI) refers to the simulation of human intelligence in machines.";
} else if (lower.includes("javascript")) {
  reply = "JavaScript is a scripting language used to create dynamic content on websites. 🖥️";
} else if (lower.includes("html")) {
  reply = "HTML (HyperText Markup Language) is used to structure content on the web.";
} else if (lower.includes("css")) {
  reply = "CSS (Cascading Style Sheets) is used to design and style the layout of web pages.";
} else if (lower.includes("openai")) {
  reply = "OpenAI is an AI research and deployment company that created me — ChatGPT!";
} else if (lower.includes("thank")) {
  reply = "You're welcome! 😊 Happy to help.";
} else if (lower.includes("bye") || lower.includes("goodbye")) {
  reply = "Goodbye! 👋 Come back anytime you have a question.";
} else if (lower.includes("how are you")) {
  reply = "I'm just code, but I'm functioning perfectly. Thanks for asking! 💻";
} else if (lower.includes("language")) {
  reply = "I can understand and respond in English. Multilingual support is in development!";
} else if (lower.includes("creator") || lower.includes("developer")) {
  reply = "I was developed by OpenAI, a team dedicated to creating safe and helpful AI.";
} else if (lower.includes("joke")) {
  reply = "Why don’t programmers like nature? It has too many bugs! 🐛😂";
} else if (lower.includes("quote")) {
  reply = "“The best way to get started is to quit talking and begin doing.” – Walt Disney";
} else if (lower.includes("love")) {
  reply = "I’m flattered! 💖 But I'm just a helpful bunch of algorithms.";
} else if (lower.includes("help")) {
  reply = "Sure! You can ask me about coding, AI, tech topics, or just say hi! 🤖";
} else {
    const randomReplies = [
  input =>
    `🧠 You've inquired about "${input}", which is an intellectually stimulating topic.\n` +
    `🌐 This concept has wide applications and deserves a thorough breakdown.\n` +
    `🔍 Let's begin by understanding its core essence in simple terms.\n` +
    `📈 We’ll then explore its broader relevance in today’s world.\n` +
    `🎯 By the end, you’ll have a comprehensive and practical understanding.`,

  input =>
    `🙏 Thank you for raising a valuable point regarding "${input}".\n` +
    `💡 This question reflects deep curiosity and analytical thinking.\n` +
    `🧱 I’ll walk you through the foundational aspects first.\n` +
    `🔗 Then we’ll delve into its real-world significance and use cases.\n` +
    `🧭 Let’s unlock this concept with clarity, structure, and depth.`,

  input =>
    `📚 "${input}" is a frequently encountered yet often misunderstood subject.\n` +
    `⚙️ It lies at the intersection of multiple disciplines and applications.\n` +
    `📝 To navigate it well, we must start with accurate definitions.\n` +
    `💬 Following that, I’ll illustrate it through practical scenarios.\n` +
    `🧠 Together, we’ll build a nuanced perspective on the topic.`,

  input =>
    `🎓 You’ve raised the topic of "${input}" — an area rich with insights.\n` +
    `🗣️ Such questions pave the way for meaningful conversations.\n` +
    `🏗️ We’ll begin by exploring its conceptual foundations.\n` +
    `🌍 Then we’ll build upon that with modern implications and relevance.\n` +
    `📚 This approach ensures both clarity and real-world context.`,

  input =>
    `🛠️ Exploring "${input}" requires a methodical and professional approach.\n` +
    `🔍 Let’s start by dissecting its key components and definitions.\n` +
    `🔄 Next, we’ll connect those elements to broader ideas and systems.\n` +
    `🧩 Through this layered understanding, patterns will emerge.\n` +
    `💡 Ultimately, you’ll gain not just answers, but insight.`,

  input =>
    `🧬 You've touched on "${input}", a topic that bridges knowledge and innovation.\n` +
    `🧠 It’s a complex idea, but we’ll make it digestible together.\n` +
    `📜 We’ll begin with its historical roots and evolution.\n` +
    `🚀 Then, we'll examine its role in contemporary applications.\n` +
    `🔓 By combining depth and clarity, we’ll demystify it fully.`,

  input =>
    `🌟 The subject of "${input}" is compelling and intellectually rich.\n` +
    `📊 To explore it effectively, we need both structure and clarity.\n` +
    `⚙️ First, I’ll outline the fundamental principles involved.\n` +
    `🧭 Next, I’ll relate those to relevant fields and use cases.\n` +
    `🎯 Let’s navigate this topic with precision and professionalism.`,

  input =>
    `🏛️ "${input}" stands as a key pillar in understanding advanced concepts today.\n` +
    `🛤️ It offers a gateway into deeper academic and practical conversations.\n` +
    `🗺️ We'll start with a brief conceptual map of the topic.\n` +
    `📚 Then build a knowledge path toward broader mastery.\n` +
    `🔍 This layered explanation will leave you confident and informed.`,

  input =>
    `💭 Let’s reflect on "${input}", a question that signals curiosity and depth.\n` +
    `🎯 Understanding this topic requires precision, not just intuition.\n` +
    `🧠 We’ll examine it through definition, context, and real-life relevance.\n` +
    `📐 I’ll ensure each layer builds clearly on the last.\n` +
    `🌟 By the conclusion, the idea will feel natural and empowering.`,

  input =>
    `🔎 Addressing "${input}" requires more than just information—it needs insight.\n` +
    `🧱 We’ll begin by simplifying its technical core.\n` +
    `🏭 Then, we’ll evaluate how it's shaping industries or conversations.\n` +
    `📌 Using relatable examples, I’ll keep the journey intuitive.\n` +
    `💼 Let’s illuminate this topic together with purpose and precision.`,
];


   const reply = randomReplies[Math.floor(Math.random() * randomReplies.length)](userMsg);
addMessage(reply, "bot");


  }

  addMessage(reply, "bot");
}


function setPrompt(text) {
  userInput.value = text;
  sendBtn.disabled = false;
  sendMessage();
}
function clearChat() {
  const chatBody = document.getElementById("chat-body");
  if (chatBody) {
    chatBody.innerHTML = "";
  }
}

