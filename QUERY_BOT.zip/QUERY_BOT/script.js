const chatBody = document.getElementById("chat-body");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

// Enable send button when there's input
userInput.addEventListener("input", () => {
  sendBtn.disabled = userInput.value.trim() === "";
});

// Handle send button click
sendBtn.addEventListener("click", () => {
  sendMessage();
});

// Handle Enter key press
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  addMessage(message, "user");
  userInput.value = "";
  sendBtn.disabled = true;

  setTimeout(() => {
    generateBotResponse(message);
  }, 500);
}

function addMessage(text, sender) {
  const chatBody = document.getElementById("chat-body");
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message", sender);
  msgDiv.textContent = text;
  chatBody.appendChild(msgDiv);
  chatBody.scrollTop = chatBody.scrollHeight;
}


function generateBotResponse(userMsg) {
  const lower = userMsg.toLowerCase();
  let reply = "";

  if (lower.includes("what is ai")) {
    reply = "AI stands for Artificial Intelligence. It's the simulation of human intelligence in machines.";
  } else if (lower.includes("machine learning")) {
    reply = "Machine learning is a subset of AI that allows systems to learn from data without being explicitly programmed.";
  } else if (lower.includes("chatgpt")) {
    reply = "ChatGPT is a language model developed by OpenAI that can generate human-like text based on input.";
  } else if (lower.includes("weather")) {
    reply = "I'm not connected to live weather data, but you can check a weather site or app like Weather.com 🌤️";
  } else if (lower.includes("python")) {
    reply = "Python is a popular, beginner-friendly programming language used in web development, AI, data science, and more.";
  } else if (lower.includes("time")) {
    reply = `The current time is ${new Date().toLocaleTimeString()}.`;
  } else if (lower.includes("your name") || lower.includes("who are you")) {
    reply = "I'm a virtual assistant created to help answer your questions and simulate ChatGPT's behavior.";
  } else if (lower.includes("hello") || lower.includes("hi")) {
    reply = "Hey there! 👋 How can I assist you today?";
  } else if (lower.includes("news")) {
    reply = "I'm not connected to live news feeds, but you can visit Google News or any major news outlet for updates.";
  } else {
    const randomReplies = [
  input => 
    `You've inquired about "${input}", which is an intellectually stimulating topic.\n` +
    `This concept has wide applications and deserves a thorough breakdown.\n` +
    `Let's begin by understanding its core essence in simple terms.\n` +
    `We’ll then explore its broader relevance in today’s world.\n` +
    `By the end, you’ll have a comprehensive and practical understanding.`,

  input => 
    `Thank you for raising a valuable point regarding "${input}".\n` +
    `This question reflects deep curiosity and analytical thinking.\n` +
    `I’ll walk you through the foundational aspects first.\n` +
    `Then we’ll delve into its real-world significance and use cases.\n` +
    `Let’s unlock this concept with clarity, structure, and depth.`,

  input => 
    `"${input}" is a frequently encountered yet often misunderstood subject.\n` +
    `It lies at the intersection of multiple disciplines and applications.\n` +
    `To navigate it well, we must start with accurate definitions.\n` +
    `Following that, I’ll illustrate it through practical scenarios.\n` +
    `Together, we’ll build a nuanced perspective on the topic.`,

  input =>
    `You’ve raised the topic of "${input}" — an area rich with insights.\n` +
    `Such questions pave the way for meaningful conversations.\n` +
    `We’ll begin by exploring its conceptual foundations.\n` +
    `Then we’ll build upon that with modern implications and relevance.\n` +
    `This approach ensures both clarity and real-world context.`,

  input =>
    `Exploring "${input}" requires a methodical and professional approach.\n` +
    `Let’s start by dissecting its key components and definitions.\n` +
    `Next, we’ll connect those elements to broader ideas and systems.\n` +
    `Through this layered understanding, patterns will emerge.\n` +
    `Ultimately, you’ll gain not just answers, but insight.`,

  input =>
    `You've touched on "${input}", a topic that bridges knowledge and innovation.\n` +
    `It’s a complex idea, but we’ll make it digestible together.\n` +
    `We’ll begin with its historical roots and evolution.\n` +
    `Then, we'll examine its role in contemporary applications.\n` +
    `By combining depth and clarity, we’ll demystify it fully.`,

  input =>
    `The subject of "${input}" is compelling and intellectually rich.\n` +
    `To explore it effectively, we need both structure and clarity.\n` +
    `First, I’ll outline the fundamental principles involved.\n` +
    `Next, I’ll relate those to relevant fields and use cases.\n` +
    `Let’s navigate this topic with precision and professionalism.`,

  input =>
    `"${input}" stands as a key pillar in understanding advanced concepts today.\n` +
    `It offers a gateway into deeper academic and practical conversations.\n` +
    `We'll start with a brief conceptual map of the topic.\n` +
    `Then build a knowledge path toward broader mastery.\n` +
    `This layered explanation will leave you confident and informed.`,

  input =>
    `Let’s reflect on "${input}", a question that signals curiosity and depth.\n` +
    `Understanding this topic requires precision, not just intuition.\n` +
    `We’ll examine it through definition, context, and real-life relevance.\n` +
    `I’ll ensure each layer builds clearly on the last.\n` +
    `By the conclusion, the idea will feel natural and empowering.`,

  input =>
    `Addressing "${input}" requires more than just information—it needs insight.\n` +
    `We’ll begin by simplifying its technical core.\n` +
    `Then, we’ll evaluate how it's shaping industries or conversations.\n` +
    `Using relatable examples, I’ll keep the journey intuitive.\n` +
    `Let’s illuminate this topic together with purpose and precision.`,

  input =>
    `"${input}" opens doors to both practical relevance and conceptual beauty.\n` +
    `We’ll examine it from theoretical and applied perspectives.\n` +
    `I’ll aim to simplify complex ideas without losing nuance.\n` +
    `By the end, you'll see its significance across multiple domains.\n` +
    `Let’s explore it step by step with clarity and intent.`,

  input =>
    `You’ve brought up "${input}", a theme worth deep exploration.\n` +
    `Let's build an understanding from its roots to its reach.\n` +
    `We’ll analyze both structure and real-world application.\n` +
    `Expect a balanced mix of technical and practical insight.\n` +
    `Let’s uncover the layers with clarity and confidence.`,

  input =>
    `The idea of "${input}" invites thoughtful interpretation and analysis.\n` +
    `We'll begin with its conceptual underpinnings.\n` +
    `Then move into how it's being implemented today.\n` +
    `I’ll tailor this journey to help you connect the dots easily.\n` +
    `Let’s turn your curiosity into informed understanding.`,

  input =>
    `You’re thinking about "${input}", which is a forward-looking inquiry.\n` +
    `It relates to modern trends and deep-rooted principles.\n` +
    `We'll bridge theoretical and real-world perspectives.\n` +
    `Each insight will add clarity to the bigger picture.\n` +
    `Let’s take this exploration to the next level.`,

  input =>
    `Exploring "${input}" reveals both complexity and opportunity.\n` +
    `It has relevance across various fields of study and work.\n` +
    `Let me present the facts in a structured, digestible form.\n` +
    `By breaking it down into parts, we simplify the complexity.\n` +
    `Let’s journey into it with purpose and precision.`,

  input =>
    `"${input}" is a subject that rewards thoughtful attention.\n` +
    `We’ll work through its definitions, context, and implications.\n` +
    `Along the way, I’ll highlight common misconceptions.\n` +
    `This will give you a clear and confident grasp of the topic.\n` +
    `Let’s begin with clarity and end with insight.`,

  input =>
    `Thank you for your inquiry into "${input}".\n` +
    `It demonstrates intellectual curiosity and intent.\n` +
    `We'll approach this concept with both simplicity and depth.\n` +
    `The goal is not just to inform, but to empower you.\n` +
    `Let’s begin with purpose and end with perspective.`,

  input =>
    `I’m glad you brought up "${input}", a core concept in many areas.\n` +
    `We’ll explore its origin, utility, and future impact.\n` +
    `I'll walk you through examples that bring the idea to life.\n` +
    `By grounding it in context, you’ll grasp it with ease.\n` +
    `Let’s dive into this thoughtfully and thoroughly.`,

  input =>
    `"${input}" deserves a lens of both curiosity and analysis.\n` +
    `Together we’ll break it down into its foundational layers.\n` +
    `I'll simplify jargon into clear, everyday language.\n` +
    `We'll close by understanding how it applies in the real world.\n` +
    `Let’s unpack it with clarity and flow.`,

  input =>
    `Your interest in "${input}" shows you're thinking deeply.\n` +
    `This topic can be technical, but we’ll keep it grounded.\n` +
    `We’ll start by defining its core mechanisms.\n` +
    `Then we’ll examine how it plays out in actual scenarios.\n` +
    `Let’s make it engaging and easy to retain.`,

  // 30 more follow (next message for space)
];


   const reply = randomReplies[Math.floor(Math.random() * randomReplies.length)](userMsg);
addMessage(reply, "bot");


  }

  addMessage(reply, "bot");
}


function setPrompt(text) {
  userInput.value = text;
  sendBtn.disabled = false;
  sendMessage();
}
function clearChat() {
  const chatBody = document.getElementById("chat-body");
  if (chatBody) {
    chatBody.innerHTML = "";
  }
}

